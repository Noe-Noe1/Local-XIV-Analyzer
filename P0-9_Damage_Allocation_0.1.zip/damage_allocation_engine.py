#!/usr/bin/env python3
"""P0-9 local damage-allocation engine.
Implements exact multiplicative percentage-buff allocation from observed status windows,
plus explicitly-labelled estimates for crit/direct-hit buffs when event metadata permits.
"""
from __future__ import annotations
import argparse,json,math,sqlite3
from collections import defaultdict
from pathlib import Path

SCHEMA='''
create table if not exists allocation_runs(
 run_id integer primary key autoincrement,created_at text default current_timestamp,
 rules_version text,fights integer,events integer,allocated_damage real,warnings integer);
create table if not exists damage_allocations(
 run_id integer,report_hash text,fight_id integer,event_seq integer,
 source_actor text,buff_owner text,buff_id text,buff_kind text,
 observed_damage real,base_damage real,allocated_damage real,
 method text,confidence text,evidence_json text);
create table if not exists dps_metrics(
 run_id integer,report_hash text,fight_id integer,actor_hash text,duration_ms real,
 raw_damage real,dps real,external_gain real,own_contribution real,
 single_target_gain real,rdps real,ndps real,adps real,cdps real,
 confidence text,warnings text,primary key(run_id,report_hash,fight_id,actor_hash));
'''
DEFAULT_RULES={'version':'p0-9.rules.1','buffs':{}}

def load_rules(path=None):
 if not path:return DEFAULT_RULES
 x=json.loads(Path(path).read_text(encoding='utf-8'))
 if not x.get('version') or not isinstance(x.get('buffs'),dict):raise ValueError('Invalid allocation rules')
 return x

def typ(e):return str(e.get('type','')).lower()
def ts(e):return float(e.get('timestamp') or 0)
def actor(e,k):return str(e.get(k) or '')
def ability(e):
 a=e.get('abilityGameID')
 if a is None and isinstance(e.get('ability'),dict):a=e['ability'].get('guid')
 return str(a or 'unknown')

def status_windows(events,rules,end):
 open_windows={};windows=defaultdict(list)
 for seq,e in enumerate(events):
  t=ts(e);k=typ(e);bid=ability(e);target=actor(e,'targetID');owner=actor(e,'sourceID')
  if bid not in rules['buffs'] or not target:continue
  key=(target,bid,owner)
  if k in {'applybuff','applydebuff','refreshbuff','refreshdebuff'}:
   if key in open_windows:windows[target].append((*open_windows.pop(key),t))
   duration=float(e.get('duration') or 0);natural=t+duration if duration>0 else end
   open_windows[key]=(bid,owner,t,min(natural,end),seq)
  elif k in {'removebuff','removedebuff'} and key in open_windows:
   bid0,owner0,start,natural,s=open_windows.pop(key);windows[target].append((bid0,owner0,start,min(t,natural),s))
 for target_items in [windows]:
  pass
 for (target,bid,owner),(bid0,owner0,start,natural,s) in open_windows.items():windows[target].append((bid0,owner0,start,natural,s))
 return windows

def split_percentage_gain(observed,active,rules):
 pct=[]
 for bid,owner,*_ in active:
  r=rules['buffs'][bid]
  if r.get('kind')=='damage_percent' and float(r.get('value',0))>0:pct.append((bid,owner,float(r['value']),r))
 if not pct:return observed,[]
 mult=math.prod(1+v for _,_,v,_ in pct);base=observed/mult;gain=observed-base
 # Shapley value over multiplicative buffs. Exact and order-independent for small raid-buff sets.
 n=len(pct);alloc=[]
 import itertools,math as _m
 for i,(bid,owner,val,r) in enumerate(pct):
  phi=0.0;others=[j for j in range(n) if j!=i]
  for size in range(n):
   for subset in itertools.combinations(others,size):
    before=base*math.prod(1+pct[j][2] for j in subset);after=before*(1+val)
    weight=_m.factorial(size)*_m.factorial(n-size-1)/_m.factorial(n)
    phi+=weight*(after-before)
  alloc.append((bid,owner,phi,r,'exact_percentage','high'))
 scale=gain/sum(x[2] for x in alloc) if alloc and sum(x[2] for x in alloc) else 1
 return base,[(a,b,c*scale,d,e,f) for a,b,c,d,e,f in alloc]

def crit_dh_estimate(observed,e,active,rules):
 out=[];crit=bool(e.get('hitType') in (2,4) or e.get('critical') or e.get('isCritical'));dh=bool(e.get('directHit') or e.get('isDirectHit') or e.get('hitType') in (3,4))
 for bid,owner,*_ in active:
  r=rules['buffs'][bid];kind=r.get('kind')
  if kind not in {'crit_rate','direct_rate'}:continue
  if (kind=='crit_rate' and not crit) or (kind=='direct_rate' and not dh):continue
  rate=float(r.get('value',0));bonus=float(r.get('bonus_multiplier',.4 if kind=='crit_rate' else .25))
  # Expected-value attribution, not FFLogs-exact RNG attribution.
  expected=max(0,observed*(rate*bonus)/(1+rate*bonus));out.append((bid,owner,expected,r,'expected_value_estimate','low'))
 return out

def run(db_path,rules_path=None):
 db=sqlite3.connect(db_path);db.executescript(SCHEMA);rules=load_rules(rules_path);run_id=db.execute('insert into allocation_runs(rules_version,fights,events,allocated_damage,warnings) values(?,0,0,0,0)',(rules['version'],)).lastrowid
 fight_count=event_count=warning_count=0;allocated_total=0.0
 for rh,fid,start,end in db.execute('select report_hash,fight_id,start,end from fights').fetchall():
  events=[]
  for seq,(p,) in enumerate(db.execute('select payload from events where report_hash=? and fight_id=? order by seq',(rh,fid))):
   try:e=json.loads(p);e['_seq']=seq;events.append(e)
   except:pass
  windows=status_windows(events,rules,float(end));raw=defaultdict(float);gain=defaultdict(float);given=defaultdict(float);single=defaultdict(float);warn=defaultdict(set)
  for e in events:
   if typ(e) not in {'damage','calculateddamage'}:continue
   src=actor(e,'sourceID');observed=float(e.get('amount') or 0)
   if not src or observed<=0:continue
   event_count+=1;raw[src]+=observed;t=ts(e);active=[x for x in windows.get(src,[]) if x[2]<=t<x[3]]
   base,allocs=split_percentage_gain(observed,active,rules);allocs+=crit_dh_estimate(observed,e,active,rules)
   if any(x[4]=='expected_value_estimate' for x in allocs):warn[src].add('crit_dh_allocation_estimated');warning_count+=1
   for bid,owner,amt,r,method,conf in allocs:
    if not owner or owner==src:continue
    gain[src]+=amt;given[owner]+=amt;allocated_total+=amt
    if r.get('targeting')=='single':single[src]+=amt
    vals=(run_id,rh,fid,e['_seq'],src,owner,bid,r.get('kind'),observed,base,amt,method,conf,json.dumps({'timestamp':t,'ability':ability(e)},separators=(',',':')))
    db.execute('insert into damage_allocations values('+','.join('?'*len(vals))+')',vals)
  duration=max(float(end)-float(start),1);actors=set(raw)|set(given)
  for a in actors:
   dps=raw[a]*1000/duration;rdps=(raw[a]-gain[a]+given[a])*1000/duration;ndps=(raw[a]-gain[a])*1000/duration;adps=(raw[a]-single[a])*1000/duration;cdps=(raw[a]-single[a]+given[a])*1000/duration
   confidence='low' if warn[a] else 'high';vals=(run_id,rh,fid,a,duration,raw[a],dps,gain[a],given[a],single[a],rdps,ndps,adps,cdps,confidence,','.join(sorted(warn[a])));db.execute('insert into dps_metrics values('+','.join('?'*len(vals))+')',vals)
  fight_count+=1
 db.execute('update allocation_runs set fights=?,events=?,allocated_damage=?,warnings=? where run_id=?',(fight_count,event_count,allocated_total,warning_count,run_id));db.commit();db.close();return {'run_id':run_id,'rules_version':rules['version'],'fights':fight_count,'damage_events':event_count,'allocated_damage':round(allocated_total,3),'warnings':warning_count}
def main():
 p=argparse.ArgumentParser();p.add_argument('--db',required=True);p.add_argument('--rules');a=p.parse_args();print(json.dumps(run(a.db,a.rules),ensure_ascii=False,indent=2))
if __name__=='__main__':main()
