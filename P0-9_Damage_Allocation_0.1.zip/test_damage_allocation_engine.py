import json,sqlite3,tempfile
from pathlib import Path
from damage_allocation_engine import run
with tempfile.TemporaryDirectory() as d:
 db=Path(d)/'x.db';rules=Path(d)/'r.json';rules.write_text(json.dumps({'version':'t','buffs':{'100':{'kind':'damage_percent','value':.1,'targeting':'party'}}}))
 c=sqlite3.connect(db);c.executescript('''create table fights(report_hash text,fight_id integer,encounter_id integer,name text,start real,end real,difficulty integer,primary key(report_hash,fight_id));create table events(report_hash text,fight_id integer,seq integer,payload text,primary key(report_hash,fight_id,seq));''');c.execute('insert into fights values(?,?,?,?,?,?,?)',('r',1,1,'b',0,10000,1))
 ev=[{'type':'applybuff','timestamp':0,'sourceID':'owner','targetID':'player','abilityGameID':100,'duration':10000},{'type':'damage','timestamp':1000,'sourceID':'player','targetID':'boss','amount':1100},{'type':'removebuff','timestamp':9000,'sourceID':'owner','targetID':'player','abilityGameID':100}]
 for i,e in enumerate(ev):c.execute('insert into events values(?,?,?,?)',('r',1,i,json.dumps(e)))
 c.commit();c.close();r=run(db,rules);assert round(r['allocated_damage'])==100
 c=sqlite3.connect(db);m=c.execute("select raw_damage,external_gain,rdps,ndps from dps_metrics where actor_hash='player'").fetchone();assert round(m[0])==1100 and round(m[1])==100 and round(m[3])==100;c.close()
print('PASS')
